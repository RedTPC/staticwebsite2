DROP TABLE IF EXISTS players;


CREATE TABLE players (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    score INTEGER,
    name TEXT
); 
