Javascript Game run on a flask application with database integration 

"flask run" to run in virtual environment

on the web, "../run.py/"
